package Dice_Game_Simulation;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;

public class GameEngine {
    ArrayList<Player> arr;
    Dice dice;

    public GameEngine(ArrayList<Player> list) {
        arr = list;
        dice = new Dice();
    }

    public void playRound() {
        int highestOp = 0;
        Player winPlayer = null;
        boolean tie = false;

        for (Player p : arr) {
            int n = dice.roll();
            System.out.println(p.showName() + " rolled: " + n);
            if (n > highestOp) {
                highestOp = n;
                winPlayer = p;
                tie = false;
            } else if (n == highestOp) {
                tie = true;
            }
        }

        if (!tie && winPlayer != null) {
            System.out.println("The player who won this round is " + winPlayer.showName() + ", rolled " + highestOp);
            winPlayer.incrementWin();
        } else {
            System.out.println("Round is a tie!");
        }
    }

    public void showResults() {
        System.out.println("Current Scores:");
        for (Player p : arr) {
            System.out.println(p.showName() + " has won " + p.showWins() + " rounds.");
        }
    }

    public void saveResultsToFile() {
        try (FileWriter writer = new FileWriter("results.txt")) {
            for (Player p : arr) {
                writer.write(p.showName() + " has won " + p.showWins() + " rounds.\n");
            }
            System.out.println("Results saved to results.txt");
        } catch (IOException e) {
            System.out.println("Error saving results: " + e.getMessage());
        }
    }
}
