package Dice_Game_Simulation;

/*
 * Holds Player info
 * 1. Name
 * 2. Wins
 */
public class Player {
    private String name;
    private int wins;

    public Player(String name) {
        this.name = name;
        this.wins = 0; // initialize to 0
    }

    public int showWins() {
        return this.wins;
    }

    public String showName() {
        return this.name;
    }

    public void incrementWin() {
        this.wins++;
    }
}
