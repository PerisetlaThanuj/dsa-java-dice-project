package Dice_Game_Simulation;

import java.util.ArrayList;
import java.util.Scanner;

public class Executer {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Give the number of players: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        ArrayList<Player> list = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            System.out.print("Player " + (i + 1) + " name: ");
            String name = sc.nextLine();
            list.add(new Player(name));
        }

        GameEngine ge = new GameEngine(list);

        while (true) {
            System.out.print("Do you want to play a round? (1: Yes / 0: No): ");
            int ip = sc.nextInt();
            if (ip == 1) {
                ge.playRound();
                ge.showResults();
            } else {
                System.out.println("Game ended. Final results:");
                ge.showResults();
                ge.saveResultsToFile();
                break;
            }
        }

        sc.close();
    }
}
