Java Dice Game Simulation Project

How to compile:
    javac Dice_Game_Simulation/*.java

Run console version:
    java Dice_Game_Simulation.Executer

Run Swing UI version:
    java Dice_Game_Simulation.GameUI

Project files:
- Player.java
- Dice.java
- GameEngine.java
- Executer.java
- GameUI.java
